/** Automatically generated file. DO NOT MODIFY */
package com.android.restaurant_menu_04;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
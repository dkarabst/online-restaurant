package com.android.restaurant_menu_04;

import org.json.JSONArray;

public interface GetDataListener 
{
    void onGetDataComplete(JSONArray result);
}

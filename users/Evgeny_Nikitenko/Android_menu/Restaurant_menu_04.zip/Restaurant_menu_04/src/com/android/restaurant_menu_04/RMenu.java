package com.android.restaurant_menu_04;

import org.json.JSONArray;

import com.android.restaurant_menu_04.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
public class RMenu extends Activity implements GetDataListener
{
	private ListView list;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rmenu);
//		list = (ListView) findViewById(R.id.lvData);
		Button button_back = (Button) findViewById(R.id.button_back);
		button_back.setOnClickListener(new View.OnClickListener() 
		{
			public void onClick(View v)
			{
				Intent intent_button_back = new Intent(RMenu.this, MainActivity.class);
				startActivity(intent_button_back);
			}
		});
		
		new GetData(this).execute();
		
	}
	
	public void onGetDataComplete(JSONArray responce) 
	{
	        // ��������� ������� ��� ListView
	}  
	
	
}
package com.android.restaurant_menu_04;

import org.json.JSONArray;

import android.os.AsyncTask;

public class GetData extends AsyncTask<Void, Void, JSONArray>
{

	private final static String SERVICE_URI = "http://10.0.2.2:8777/.../service.php";
	private GetDataListener listener;

	GetData(GetDataListener listener)
	{
		this.listener = listener;
	}

	protected void onPostExecute(JSONArray result)
	{
		listener.onGetDataComplete(result);
	}

	protected JSONArray doInBackground(Void... params)
	{
		return CallService();
	}

	private JSONArray CallService() 
	{
        JSONArray records = null;
                // �������� ���� ������ � ����������
        return records;
    }
}
